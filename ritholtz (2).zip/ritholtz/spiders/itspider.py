# -*- coding: utf-8 -*-
import scrapy
from ritholtz.items import RitholtzItem

class ExampleSpider(scrapy.Spider):
    name = 'itspider'
    allowed_domains = ['ritholtz.com']

    def start_requests(self):
        for i in range(2001,3904):
            url = f"https://ritholtz.com/page/{i}"
            yield scrapy.Request(url,callback=self.parse)

    def parse(self, response):
        artobj = response.xpath('//div[@class="inner-main"]/article')
        for art in artobj:
            aobj = art.xpath('div[@class="hpad clearfix"]/header[@class="article-header"]/a')[0]
            url = aobj.xpath('@href').extract_first()
            title = aobj.xpath('@title').extract_first()
            meta_dict = {
                "title":title,
                "url":url
            }
            yield scrapy.Request(url,
                                     callback=self.parse_detail,meta=meta_dict)


    def parse_detail(self,response):
        item = RitholtzItem()
        contentobj = response.xpath('//div[@class="hpad clearfix"]/header/p[@class="post-meta"]')[0]
        author_url = contentobj.xpath('a/@href').extract_first()
        timedate = contentobj.xpath('string(.)').extract_first().strip("").split("by")

        #文本。提取全部的文本内容。
        wenbenobj = response.xpath('//div[@class="hpad clearfix"]/div[@itemprop="articleBody"]/div[@class="pf-content"]') or \
        response.xpath('//div[@class="hpad clearfix"]/div[@itemprop="articleBody"]')
        info = wenbenobj.xpath('string(.)').extract_first()

        item["title"] = response.meta["title"]
        item["url"] = response.meta["url"]
        item["author"] = timedate[1].strip()
        item["datecreated"] = timedate[0].strip()
        item["author_url"] = author_url
        item["content"] = info

        yield item
