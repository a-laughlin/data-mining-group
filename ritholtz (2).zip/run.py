from scrapy import cmdline

cmdline.execute('scrapy crawl itspider -o 2001-3904data.json'.split())